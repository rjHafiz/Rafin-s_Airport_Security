#include "server.h"
#include <fstream>

using namespace std;

#ifndef facility_h
#define facility_h

class Facility
{
public:
    Facility(double arrivalMean1, double arrivalMean2, double arrivalMean3, double arrivalMean4);
    void report();
    void initialize();
    void arrivalHandler(int road);

    void createTraceFile();
    inline ofstream& trace() { return trace_; }

    int cnt;

private:
    Server* server1;
    Server* server2;
    Server* server3;
    Server* server4;

    ofstream trace_;

    double uniformRand(double minn, double maxx);
};

#endif


