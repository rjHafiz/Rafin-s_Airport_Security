#ifndef event_h
#define event_h

class Server;

class Event
{
	public:
		Event (Server* s) : server (s) {
 			stime_ = 0.0;
			rtime_ = 0.0;
		}

   		inline int& eventType () { return (eventType_); }
		inline double& expire () { return (rtime_); }
		inline double& start () { return (stime_); }

		void activate (double t,int id);
		void cancel ();
		virtual void handle (int road) = 0;

		Event* next_;
		int road;
	protected:
		Server* server;

	private:
		int eventType_;
		double stime_;
		double rtime_;
		int status_;

};

class ArrivalEvent : public Event
{
	public:
 		ArrivalEvent (Server* s) : Event(s) {}
		void handle (int road);

};

class DepartureEvent : public Event
{
	public:
		DepartureEvent (Server* s) : Event(s) {}
		void handle (int road);
};

#endif












