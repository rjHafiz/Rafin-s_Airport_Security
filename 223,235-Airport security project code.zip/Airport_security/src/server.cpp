#include "server.h"
#include "scheduler.h"

#include <malloc.h>
#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;


Server :: Server (int id, Facility* facility) : a_(this), d_(this), id_(id), facility_(facility)
{
	queue_ = new Queue ();
	itemArrived_ = 0;
}


double
Server :: exponential(double mean) {

	double r = (double)rand()/(RAND_MAX+1);
	double ex = -mean * log (r);
	return ex;

}



void
Server :: initialize () {
	status_ = 0;
	itemArrived_ = 0;
	timeLastEvent_ = 0;

	areaQueue_ = 0;

	totalQueueDelay_ = 0.0;
	totalSystemDelay_ = 0.0;
	totalCustomerServed_ = 0;
}


void Server :: triggerArrival (int id) {
    itemArrived_++;
    if(itemArrived_ <= 100) {
        double t = exponential(arrivalMean_);
        facility_->trace() << "id: " << id << "\tinterarrival time = " << t << endl;
        a_.activate(t+Scheduler :: now (),id_);
    }
}


void Server :: facilityArrivalHandler (int road) {
    facility_ -> arrivalHandler(road);
}

void
Server :: serverArrivalHandler (Item* temp,int road) {
    facility_->trace() << "a\t" << id_ << "\t" << Scheduler::now () <<  "\t" << status_ << "\t" << queue_->length() << endl;

//    updateStat();

    if(status () == 0) { // server is idle during arrival
    	status() = 1;
    	facility_->trace() << "s\t" << id_ << "\t" << Scheduler::now () << "\t" << status_ << "\t" << queue_->length() << endl;
    	itemInService_ = temp;
    	queueDelay_ = Scheduler::now() - itemInService_ -> arrivalTime;
    	totalQueueDelay_ += queueDelay_;

        double t = exponential (departureMean_);
        facility_->trace() << "\tservice time = " << t << endl;
    	d_.activate(t+Scheduler :: now (),id_);
    } else {
    	queue_ -> enque(temp);
    }


    double t = exponential (departureMean_);


    double timee = Scheduler::now ();
    int check = ceil(timee);
    cout << "check: " << check % 4 <<endl;
    if(road==1 || road==3){
        if(check%4==1 || check%4==3){
            //d_.activate(t+Scheduler::now (),id_);
        }
        else{

            //d_.activate((4.0+Scheduler::now()),id_);
            queue_length = queue_->length();
            queue_length++;
            totalQueueDelay_ += 1.0;
        }
    }

    if(road==2 || road==4){
        if(check%4==0 || check%4==2){
            //d_.activate(t+Scheduler::now (),id_);
        }
        else{
            //d_.activate(5.0+Scheduler::now(),id_);
            queue_length = queue_->length();
            queue_length++;
            totalQueueDelay_ += 2.0;
        }
    }



    triggerArrival(id_);

}


void
Server :: departureHandler () {

    facility_->trace() << "d\t" << id_ << "\t" << Scheduler::now () << "\t"  << 0 << "\t" << queue_->length() << endl;

//	totalCustomerServed_++;
//	systemDelay_ = Scheduler::now() - itemInService_ -> arrivalTime;
//	totalSystemDelay_ += systemDelay_;


//    if(queue_->length() > 0){
 //       itemInService_ = queue_->deque();

 //       facility_->trace() << "s\t" << id_ << "\t" << Scheduler::now () << "\t" << itemInService_->id_ << "\t" << status_ << "\t" << queue_->length() << endl;

  //      queueDelay_ = Scheduler::now() - itemInService_ -> arrivalTime;
  //      totalQueueDelay_ += queueDelay_;

	//	double t = exponential(departureMean_);
	//	facility_->trace() << "\tservice time = " << t << endl;
		//d_.activate(t,1);
	//} else {
	//	status() = 0;
	//	itemInService_ = 0;
	//}


}



