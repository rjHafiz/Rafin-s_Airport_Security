#include "facility.h"

Facility::Facility(double arrivalMean1, double arrivalMean2,
                   double arrivalMean3,double arrivalMean4) {

    server1 = new Server(1, this);
    server2 = new Server(2, this);

    server3 = new Server(3, this);
    server4 = new Server(4, this);

    server1 -> arrivalMean() = arrivalMean1;
    server2 -> arrivalMean() = arrivalMean2;
    server3 -> arrivalMean() = arrivalMean3;
    server4 -> arrivalMean() = arrivalMean4;

    /**
     server1->departureMean() = serviceMean;
     server2->departureMean() = serviceMean;
     **/

     cnt = 0;
}

double
Facility :: uniformRand(double minn, double maxx) {
    double u = (double)rand()/RAND_MAX;
    double ur = minn + u * (maxx-minn);
    return ur;
}


void Facility::initialize() {
    createTraceFile();

    server1 -> initialize();
    server2 -> initialize();

    server3 -> initialize();
    server4 -> initialize();

    server1 -> triggerArrival(1);

    server2 -> triggerArrival(2);

    server3 -> triggerArrival(3);

    server4 -> triggerArrival(4);

}

void Facility:: arrivalHandler(int road) {

    Item* temp;
    temp = (Item*) malloc(sizeof(Item));
    temp -> arrivalTime = Scheduler :: now();

    if(road == 1 ){
        server1 -> serverArrivalHandler(temp,road);
    }
    else if(road == 2 ){
        server2 -> serverArrivalHandler(temp,road);
    }
    else if(road == 3 ){
        server3 -> serverArrivalHandler(temp,road);
    }
    else if(road == 4 ){
        server4 -> serverArrivalHandler(temp,road);
    }

}

void Facility :: createTraceFile () {
	trace_.open ("trace.out", ios::out);
	if (!trace_) {
		cout << "cannot open the trace file.\n";
	}
	trace_<< "trace file for the simulation" << endl;
	trace_ << "format of the file" << endl;
	trace_ << "<event> <server id> <time> <server status> <queue size>" << endl << endl << endl;
}

void Facility::report() {
    ofstream report_;
    report_.open("report.csv", ios::app);
    report_ << server1->totalQueueDelay()/100<<","<<double(server1->queue_length/Scheduler::now())<<","<<(400/Scheduler::now())*2.0<<endl;
    report_ << server2->totalQueueDelay()/100<<","<<double(server2->queue_length/Scheduler::now())<<","<<(400/Scheduler::now())*2.25<<endl;
    report_ << server3->totalQueueDelay()/100<<","<<double(server3->queue_length/Scheduler::now())<<","<<(400/Scheduler::now())*2.5<<endl;
    report_ << server4->totalQueueDelay()/100<<","<<double(server4->queue_length/Scheduler::now())<<","<<(400/Scheduler::now())*2.75<<endl<<endl;

    report_.close();

}


