#include "event.h"
#include "server.h"
#include "scheduler.h"

void
Event :: activate (double t,int id) {
	Scheduler &s = Scheduler :: instance ();
   	stime_ = Scheduler :: now ();
	rtime_ = t;
	road = id;
	s.schedule (this);
}

void
Event :: cancel () {
	//Scheduler :: cancel (this);
}

void
ArrivalEvent :: handle (int road) {
	server -> facilityArrivalHandler(road);
}

void
DepartureEvent :: handle (int road) {
	server -> departureHandler();
}





