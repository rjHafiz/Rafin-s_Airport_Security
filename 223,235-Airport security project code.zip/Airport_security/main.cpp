#include <iostream>
#include <fstream>
#include <time.h>
using namespace std;

#include "scheduler.h"
#include "facility.h"

#include "event.h"
#include "server.h"

int main ()
{
    ///
    srand(time(0));
    ofstream report_;
    report_.open("report.csv", ios::out);
    if(!report_) {
        cout<<"cannot open report file.\n";
        return 1;
    }
    report_<<"Passenger Intensity,Average Queue Length, Average Queue Delay"<<endl;
    report_.close();


        Scheduler *sch = new Scheduler();
        sch -> initialize();

        Facility* facility = new Facility(3,4,5,6);
        facility -> initialize();

        sch->run();

        facility -> report();

	return 0;
}
